<?php
$groupName = 'ditaperday';
$groupOwner = 'Don Day';
$organization = 'donrday.com';
$copyrOwnerEmail = 'donday@donrday.com';

$appType = 'app';
$siteName = 'DITA per Day';
$siteSlogan = 'Facets of Intelligent Content';
$siteType = 'blog';
$defaultThemeName = 'clearfocus';
$defaultEditorName = 'text';
$defaultDitaType = 'basic';

$serviceTypes = array('about','admin');
$labels = array('About','Admin');

// tab definitions

	$config['about']['topic'] = 'about';
	$config['about']['label'] = 'About';
	$config['about']['areaType'] = 'page';
	$config['about']['sidebarItems'] = 'navigation,search,sites';//draft

	$config['admin']['topic'] = 'admin'; 
	$config['admin']['label'] = 'Setup';
	$config['admin']['areaType'] = 'admin';
	$config['admin']['sidebarItems'] = 'navigation,search,profile,personalization,jotsommarkdown';
