<?php
	
session_start(); 

// INSTALLERS! Please observe the CONFIG: steps for the minor but important configuration setup values.

// CONFIG #ERRORS: use true when deploying for actual use; use false to allow dev messages to show.
define('IN_PRODUCTION', FALSE); 

// CONFIG #HOST: set this to the hostname by which URLs will access this application  (e.g., 'http://jotsom.com')
define('SERVERNAME', 'http://localhost'); 

// CONFIG #FOLDER: set this to the installed folder path relative to server root
define('INSTALL_FOLDER', 'any2dita/'); // 'Journal/' 

// CONFIG #OFFSET: set this to the installed folder path relative to server root
// Note: can't use 'jotsom' as folder name since it confused rewrite 'real' rules // 'jotsom1'
define('INSTALL_OFFSET', ''); // 'jotsom1/

// CONFIG #APP: set these values to the relative names and offset of App folder outside of pkg
$appOffset = INSTALL_OFFSET.'pkg/'; // 'pkg/'
$appDir = ''; // 'App'

// CONFIG #CONTENT: set these values to the relative names and offset of Content folder outside of pkg
$contentOffset = '';//'../'; // '../'
$contentDir = 'Content';

// CONFIG #THEMES: set these values to the relative names and offset of Theme folder outside of pkg
$themesOffset = '';//'../';
$themesDir = 'Themes';

// CONFIG #VENDOR: set these values to the relative names and offset of Vendor folder outside of pkg
$vendorOffset = '';
$vendorDir = 'Vendor';

// Other relative folder and path names
$siteURL = "http://" . $_SERVER['HTTP_HOST'].'/'.INSTALL_FOLDER;//add groupName as needed
$siteURL2 = strtok($_SERVER['REQUEST_URI'], '?'); // used only when parameter queries need to be stripped off
$appdbPath = 'groups.db'; // This path is used only for login. Full model should cover members, content, comments... 
$dbname = 'base.db'; // This path is for content.
$libDir = 'Lib/'; // unused
$viewDir = 'View/'; // unused

// Get runtime settings.
require_once INSTALL_OFFSET.'appconfig.php';

//include files for adding plugin functionality. These depend on vars and functions defined in appconfig for ease of setup.
// CONFIG #PLUGIN: Edit the following file to update its config path, if changing from the default $appOffset path.
require_once INSTALL_OFFSET.'pkg/'.'pluginsystem.php';

hook_action('init');

// Apply parameter queries
require_once INSTALL_OFFSET.'Lib/frontlogic.php';

// Decompose the URL, type the segments, and assign controllers.
require_once INSTALL_OFFSET.'router.php'; 

// At this point, we know all we'll know about the query and could start some preliminary processing.

// Separate configs for users and resources (router has given us groupName by now)
if ($groupName == 'users') {
	// Get user management settings
	///require_once INSTALL_OFFSET.'memberconfig.php';
//} elseif () {} ...could add other config categories later.
} else {
	// Get group-specific settings.
	///require_once INSTALL_OFFSET.'groupconfig.php'; 
} 

/* Now we get into the application proper, so the path changes from the install folder to the appalication folder $appDir.*/


// "Model" - load business logic to use on requests
// Hook to load model (data manipulation) functions in advance of their use.
//include $appDir."Model/db-all.php";
hook_action('load_model');// Not developed yet (need to load or rename "pkg/plugins/action_headless).
///require_once INSTALL_OFFSET.'Lib/sqlib.php';
require_once INSTALL_OFFSET.'Lib/filelib.php';
// Apply parameter queries
///require_once INSTALL_OFFSET.'Lib/CRUDlogic.php';

// Hook for headless (non-GUI or non-content) CRUD processing requests against the model.
hook_action('load_actions');// Not developed yet (need to load or rename "pkg/plugins/action_headless).
require_once INSTALL_OFFSET.'Lib/functions.php';

// "View" - Render data by appType (api, site, blog, wiki, etc.):
// For extended expeDITA apps, the appType may name a more particular controller and its data/views (eg, wikiController).
if ($appType == 'api') {
	// No ops for now
	hook_action('load_nonsite'); // not developed yet
	// Call the controller selected by the router
	// Fetch and render request...
} else {
	hook_action('load_site'); // not developed yet
	require_once INSTALL_OFFSET.'Lib/UIfunctions.php';

	// Set up theme dependencies and inner styles.
	require_once themePath().'defs/themeconfig.php';
	require_once themePath().'defs/viewconfig.php';
	///include 'View/viewsTheme.php'; // Defines template insertion points: content(), footer(), endpoint(), etc..

	// Call the controller selected by the router
	// $controller names a function defined in routes.php.
	hook_action('content_request'); // This hook allows alternate routing patterns to override the default for Jotsom.
	if(is_callable($controller)) {  
	  	$post = $controller();
	} else {
		$post['content'] = $controller.' is not available.'; // This needs 404 logic. Redirect as best course?
	}

	// Result content is instanced into the chosen template's current area types and user controls.
	hook_action('page_load');
	hook_action('template_init');
	require_once themePath().'defs/template.php';
	hook_action('page_exit');
}

/* Enable some end-of-page diagnostic/demo widgets, etc.. */
//hook_action('ui_tools');
hook_action('select_theme');
//hook_action('select_xtype');
//hook_action('show_comments'); //showCategories();
//hook_action('select_author'); showAuthors();
hook_action('exit');

/* Include pattern in a nutshell: */
// INSTALL_OFFSET.'			appconfig.php';
// INSTALL_OFFSET.'pkg/'.'	pluginsystem.php';
// 'Lib/					frontlogic.php'; // param queries that do not depend on the URL (eg headless CRUD ops)
// INSTALL_OFFSET.'			router.php';  // Process the RESTful URL (which may have parameter segments)
// INSTALL_OFFSET.'			groupconfig.php'; 
// 'Lib/					functions.php';
// 'Lib/					UIfunctions.php';
// themePath().'defs/		themeconfig.php';
// themePath().'defs/		viewconfig.php';
// themePath().'defs/		template.php';

?>