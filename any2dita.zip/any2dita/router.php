<?php

// Router results
$groupName = 'any2DITA';
$serviceType = 'about';
$controller = 'nothing';
$queryType = 'topic';
$resourceName = 'about';
	if ($pagenum == '*') {$pagenum = 15;$tabType = 'about';}

// group lookup
$siteName ='Any2DITA';
$siteSlogan = 'New lamps for old';
$siteOwner = 'Don Day';
 $defaultThemeName = 'haven';
//$fileName = 'Events.dita';

$serviceTypes  = array('about','admin');
//$tabType = 'admin';
//$_SESSION['serviceType'] = 'admin';
$config['admin']['sidebarItems'] = 'pages';
	$config['admin']['label'] = 'Migrate';
	$config['admin']['url'] = $siteURL.'/?tab=admin';
$config['about']['sidebarItems'] = 'pages';
	$config['about']['label'] = 'About';
	$config['about']['url'] = $siteURL.'/?tab=about';

/* Define local widgets: key, form name, data-as-array */
$itemdefs = array(
	'navigation'	=>	array('SiteNav','navigation',array('')),
	'profile'		=>	array('Profile','form_profile',array('')),
	'personalization'=>	array('Profile','form_personalization',array('')),
	'jotsommarkdown'=>	array('jotsommarkdown','jotsommarkdown',array('')),
	'jotsomwysiwyg'=>	array('jotsomwysiwyg','jotsomwysiwyg',array('')),
	'sites'			=>	array('Sites','form_sites',array('')),

	'navi'			=>	array('SiteNav','form_navigation',array('')),
	'search'		=>	array('Search','form_search',array('')),
	'categories'	=>	array('Categories','form_categories',get_categories()),
	'archives'		=>	array('Archives','form_archives',array('')),
	'pages'			=>	array('Pages','form_pages',array('')),
	'blogroll'		=>	array('Blogroll','form_blogroll',array('')),
	//'authors'		=>	array('Authors','form_authors',get_authors()),
	'new'			=>	array('New Entry','form_create',array(''))
);


/* "Group definitions" (these depend on the $groupName as a valid location) */

function groupPath() {
	global $groupName;
	return BASE_URL.$groupName.'/';
}

// Used to house common theme support code (sliders and shortcodes, especially)
function commonPath() {
	global $themesDir, $themeName;
	return "$themesDir/common/";
}
	function themePath() {
		global $themesOffset, $themeName;
		return $themesOffset."Themes/$themeName/";
	}

?>
