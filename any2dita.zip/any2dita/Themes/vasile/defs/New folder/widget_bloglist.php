<?php
// For the SimpleTheme, this custom widget adds a light grey background for the first topic.
// verified wrappers for page layout in winterplain theme.



if ($counter < 4) {
	?>
	<div class="feature">
			<div class="post">
				<?php //playPost($targurl);?>
				<?php include(themePath().'defs/widget_post.php');?>
			</div>
	</div>
	<?php
} else {
	?>
		<div class="post">
			<?php //playPost($targurl);?>
			<?php include(themePath().'defs/widget_post.php');?>
		</div>
	<?php
}
