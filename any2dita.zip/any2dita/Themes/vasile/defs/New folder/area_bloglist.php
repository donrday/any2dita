<?php
// verified wrappers for list of post layout in winterplain theme.
$postid = '37';
$postURL = '?read=37';
$postDate = date('M d, Y'); //'Jun 13, 2006'; 
$postAuthor = 'Quid Nunc';
$authorInfo[$postAuthor]['realname'] = 'Duis Emit';
$authorInfo[$postAuthor]['site'] = 'http://example.com';
$comments[$postid] = array('Very nice.','I don\'t understand you.','May I quote you?','Imitation Gucci bags, cheap');
$numcomments = sizeof($comments);
$tags[$postid] = 'arcu, eget, pretium, porttitor';

// normally the endpoint renders here. A bloglist uses first post as the splash post.

$infile = $config[$serviceType]['featuredMap'];
$style = $config[$serviceType]['itemStyle'];

listMapAsList($infile, 'bloglist'); 
