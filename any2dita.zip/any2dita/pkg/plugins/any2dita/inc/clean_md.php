<?php
// functions for editor/transform manipulation of save stream

function transformMD($instr, $prefix="xform") {
	return "IN TRANSFORM markdown";
}
