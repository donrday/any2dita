<?php
global $appType;
//echo "appType2: $appType<br/>";
// DRD: I thought this was a global context, but I had to make the var global. Is this in a function scope?

register_action('template_init','a2d_themesetup');
function a2d_themesetup() {
	function pageTitle() {
		global $siteName;
		echo $siteName;
	}

	function metaTitle() {
		return '';
	}
	
	function metaDesc() {
		return '';
	}
	
	function metaKeywords() {
		return '';
	}
	
	function metaCanonical() {
		global $url;
		return SERVERNAME.'/'.trim($url, '/');
	}
	//*/

	function siteURL() {
		echo 'any2dita/';
		return;
	}
	function siteName() {
		global $siteName;
		echo $siteName;
	}
	function siteSlogan() {
		global $siteSlogan;
		echo $siteSlogan;
	}
	function xnavigation() {
	?><ul>
	<li>nav items here</li>
	</ul><?php
	}
	function xfooter() {
	}
}

register_action('scripts_body_event','dobodyjs');
function dobodyjs() {
echo ' onload="init()"';
}

//echo "APPTYPE: $appType<br/>";exit;
if ($appType == 'any2dita') {
	register_action('xpd_cssjs','tabContent_styles'); // hook_action('xpd_cssjs');

	function tabContent_styles() {
	?>
	    <style type="text/css">
	      ul#tabs { list-style-type: none; margin: 30px 0 0 0; padding: 0 0 0.2em 0; } /*padding was 0 0 0.3em 0*/
	      ul#tabs li { display: inline; }
	      ul#tabs li a { color: #42454a; background-color: #dedbde; border: 1px solid #c9c3ba; border-bottom: none; padding: 0.3em; text-decoration: none; }
	      ul#tabs li a:hover { background-color: #f1f0ee; }
	      ul#tabs li a.selected { color: #000; background-color: #f1f0ee; font-weight: bold; padding: 0.7em 0.3em 0.38em 0.3em; }
	      div.tabContent { border: 1px solid #c9c3ba; padding: 0.5em; background-color: #f1f0ee; }
	      div.tabContent.hide { display: none; }
	    </style>
	
	    <script type="text/javascript">
	    //<![CDATA[
	
	    var tabLinks = new Array();
	    var contentDivs = new Array();
	
	    function init() {
	
	      // Grab the tab links and content divs from the page
	      var tabListItems = document.getElementById('tabs').childNodes;
	      for ( var i = 0; i < tabListItems.length; i++ ) {
	        if ( tabListItems[i].nodeName == "LI" ) {
	          var tabLink = getFirstChildWithTagName( tabListItems[i], 'A' );
	          var id = getHash( tabLink.getAttribute('href') );
	          tabLinks[id] = tabLink;
	          contentDivs[id] = document.getElementById( id );
	        }
	      }
	
	      // Assign onclick events to the tab links, and
	      // highlight the first tab
	      var i = 0;
	
	      for ( var id in tabLinks ) {
	        tabLinks[id].onclick = showTab;
	        tabLinks[id].onfocus = function() { this.blur() };
	        if ( i == 0 ) tabLinks[id].className = 'selected';
	        i++;
	      }
	
	      // Hide all content divs except the first
	      var i = 0;
	
	      for ( var id in contentDivs ) {
	        if ( i != 0 ) contentDivs[id].className = 'tabContent hide';
	        i++;
	      }
	    }
	
	    function showTab() {
	      var selectedId = getHash( this.getAttribute('href') );
	
	      // Highlight the selected tab, and dim all others.
	      // Also show the selected content div, and hide all others.
	      for ( var id in contentDivs ) {
	        if ( id == selectedId ) {
	          tabLinks[id].className = 'selected';
	          contentDivs[id].className = 'tabContent';
	        } else {
	          tabLinks[id].className = '';
	          contentDivs[id].className = 'tabContent hide';
	        }
	      }
	
	      // Stop the browser following the link
	      return false;
	    }
	
	    function getFirstChildWithTagName( element, tagName ) {
	      for ( var i = 0; i < element.childNodes.length; i++ ) {
	        if ( element.childNodes[i].nodeName == tagName ) return element.childNodes[i];
	      }
	    }
	
	    function getHash( url ) {
	      var hashPos = url.lastIndexOf ( '#' );
	      return url.substring( hashPos + 1 );
	    }
	
	    //]]>
	    </script>
	<?php
	}
}

if ($appType == 'any2dita') {
	register_action('a2d_form','view_tabbed_forms'); // hook_action('a2d_form');
	
	function view_tabbed_forms() {
	global $sRtf, $sXml, $sMdn, $sWkm;
	?>
	
	<ul id="tabs">
	  <li><a href="#htmlform">HTML</a></li>
	  <li><a href="#rtform">Rich Text</a></li>
	  <li><a href="#mdform">Markdown</a></li>
	  <li><a href="#wkform">Wikimedia</a></li>
	</ul>
	
	<div class="tabContent" id="htmlform">
		<form method="post" action="">
			<textarea name="htmlin" style="height:200px;width:100%" rows='5' cols='60' placeholder="Paste HTML content here"
			><?php //echo $sXml;?></textarea>
			<br/><b>OR</b><br/>
			URL of known HTML page: (this field is still under construction; use paste above for now)
			<br/><input type="text" name="pagename" placeholder="output document name"/>
			<br/><input type="text" name="prefix" placeholder="output file 'namespace'"/>
			<br/><input type="text" name="topictype" value="concept"/>
			<br/><input name="htsub" type="submit" value="Proceed to migrate"/>
		</form>
	</div>
	
	<div class="tabContent" id="rtform">
		<form method="post" action="">
			<textarea name="rtfin" class="WYSIWYG"
				title="block text left center right insert link image table source" 
				style="height:200px;width:100%" rows='5' cols='60' placeholder="Paste Rich Text content here"
				><?php echo $sRtf;?></textarea>
			<br/><input type="text" name="pagename" placeholder="output document name"/>
			<br/><input type="text" name="prefix" placeholder="output file 'namespace'"/>
			<br/><input type="text" name="topictype" value="concept"/>
			<br/><input  name="rtsub"type="submit" value="Clean"/>
		</form>
	</div>
	
	<div class="tabContent" id="mdform">
		<form method="post" action="">
			<textarea name="mdin" style="height:200px;width:100%" rows='5' cols='60' placeholder="Paste markdown content here"
			><?php //echo $sMdn;?></textarea>
			<br/><b>OR</b><br/>
			URL of known Markdown page:
			<input type="text" name="url" placeholder="URL"/>
			<p>Endpoint example: <b>http://daringfireball.net/projects/markdown/basics.text</b></p>
			<p>Markdown sample: <a href="http://daringfireball.net/projects/markdown/basics.text">daringfireball.net/projects/markdown/basics.text</a></p>
			<br/><input type="text" name="pagename" placeholder="output document name"/>
			<br/><input type="text" name="prefix" placeholder="output file 'namespace'"/>
			<br/><input type="text" name="topictype" value="concept"/>
			<br/><input name="mdsub" type="submit" value="Clean"/>
		</form>
	</div>
	
	<div class="tabContent" id="wkform">
		<form method="post" action="">
			<textarea name="wkin" style="height:200px;width:100%" rows='5' cols='60' placeholder="Paste wikitext content here"
			><?php //echo $sWkm;?></textarea>
			<br/><b>OR</b><br/>
			URL of known Mediawiki page:
			<input type="text" name="endpoint" placeholder="wiki endpoint"/> / <input type="text" name="pagename" placeholder="page name"/>
			<p>Endpoint example: <b>http://www.mediawiki.org/wiki</b> /FAQ</p>
			<p>Page name example: http://www.mediawiki.org/wiki/ <b>FAQ</b></p>
			<br/><input type="text" name="pagename" placeholder="output document name (page title)"/>
			<br/><input type="text" name="prefix" placeholder="output file 'namespace (up to 4 chars)'"/>
			<br/><input type="text" name="topictype" value="concept"/>
			<br/><input name="wksub" type="submit" value="Clean"/>
		</form>
	</div>
	<?php
	}
}


?>