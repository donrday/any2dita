<?php
// Resources for markdown:
// http://mrcoles.com/demo/markdown-css/
// http://fvsch.com/code/remarkdown/
// http://web.archive.org/web/20110828143453/http://getspace.org/typographic-contras-minimalist-web-design/
// HTML sample: http://txti.es/aea-2014-wroblewski
// Markdown sample: http://daringfireball.net/projects/markdown/index.text
// Resources for mediawiki api:
// Resources for rich text (contentEditable) 
	

register_filter('any2dita','any2dita_logic'); // or template-init

function any2dita_logic() {
	global $a2dxsl, $targ_path, $fullpath, $imglist;

	// Set up individualized folders for result files, anticipating heavy traffic:
	$job_name = 'zip'.rand(1000, 9999);
	$zip_name = $job_name.'.zip';
	$targ_path = 'STAGE/'.$job_name;
	$targ_filepath = $targ_path.'/'.$zip_name;
	
	// Defaults for form values (both get and post):
	$in_text = ''; // presett so we can expose the value in pre-submission value (normally is set by main.php)
	$prefix = 'temp';
	$outmapname = 'map'.rand(1000, 9999);
	$outputpath = pluginsPath()."any2dita/".$targ_path;

	// CONFIG #CONTENT: set these values to the relative names and offset of Content folder outside of pkg
	$contentOffset = ''; // '../'
	$contentDir = '';//'Content';
	$groupName = 'temp';

	$mapName = $outmapname.'ditamap';
	$msg = '';
	$imglist = array(); 

	//include('App/views.php'); // 
	include('inc/tools.php'); // functions

	// process GET and POST events
	include('inc/main.php'); // controllers
	
	// At this point, if GET was triggered, then content is uniformly in HTML form in var $in_text.
		//echo "<h2>in_text:</h2>";
		//echo '<pre>'.htmlentities($in_text).'</pre>';

	if ($msg != '') {
		$outputmapname = 'asdf';
	
		// If we got this far, it is a real request--time to set up for results:
		if (!file_exists($targ_path)) {
		    mkdir($targ_path, 0777, true);
		}
		
		//echo "targ_path: $targ_path<br/>";
		//$a2dxsl = pluginsPath().'any2dita/xsl/';
		//$a2dxsl = 'xsl/';
		//echo "a2dxsl: $a2dxsl<br/>";
		//echo 'dirname: '.dirname(__FILE__).'<br/>';

		// convert interim into proto form (and copy resources over)
		include 'inc/clean_html.php';
		$sXml = transformHTML($in_text,   '|div|', dirname(__FILE__).'/xsl/html2mid.xsl', $prefix);
	
		// Transform the intermediate into DITA 
		$resultXML = transformXML($sXml, dirname(__FILE__).'/xsl/mid2dita.xsl', $targ_path); 

		// Final: write intermediate file to the target directory
		$ifile = $targ_path.'/proto.xml';
		file_put_contents($ifile, $sXml);

		// Final: write map to the target directory (topics are already there)
		// This output path should match what the mid2dita.xsl chunking template writes to. 
		$ffile = $targ_path.'/'.$outmapname.'.ditamap';
		file_put_contents($ffile, $resultXML);
	
		// Create zip and copy into result folder
		$ofiles = glob($targ_path.'/*.*');// use braces to limit filetypes
		//var_dump($ofiles);
		$zipstatus = zip_files($ofiles, $zip_name);
		rename($zip_name, $targ_filepath);
	
		//save_to_zip($zip_name); 
		
		// Wrap up: notify the user and provide a link to the file.
		// Reference: http://stackoverflow.com/questions/8328983/php-check-if-an-array-is-empty
		// Reference: http://forums.phpfreaks.com/topic/144592-delete-file-immidiately-after-download/ ("immidiately" is part of the URL; don't fix it!)
		ob_start();
		echo'<h3>Results for: '. $msg.' (RC="'.$zipstatus.'")</h3>';
		//echo 'Result map: <a href="'.$ffile.'" target="_new">here</a><br/>';
		echo 'Intermediate format: <a href="'.$ifile.'" target="_new">here</a><br/>';
		echo 'Your zipped result package is ready to download: <a href="'.$targ_filepath.'" target="_new">here</a>.<br/>';
		echo 'Image resources to copy:<ul>';
		foreach($imglist as $pic) {
			echo '<li><a href="'.$pic.'" target="_blank">'.$pic.'</a></li>';
		}
		echo '</ul>';
		$linkedmap = transformXML($resultXML, dirname(__FILE__).'/xsl/verbid.xsl', $targ_path); 
		echo 'Sample the results:';
		echo '<pre>'.$linkedmap.'</pre>';
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}




}

?>