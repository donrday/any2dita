$(document).ready(function() {
$( "#scriptTest" ).click(function() {
    alert("it's working");
});
});