<?php
?><!doctype html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />

		<!-- expeDITA specific contribution -->
		<meta name="generator" content="expeDITA 0.2" />
		<title><?php pageTitle();?></title>

		<?php hook_action('xpd_meta');?>

		<!-- Theme specific resources -->
		<meta name="theme" content="common" />
		<meta name="source" content=""/>
		<link href="<?php echo themePath();?>style.css" rel="stylesheet" type="text/css" />

		<?php hook_action('xpd_cssjs');?>
		<?php hook_action('user_cssjs');?>
		<?php hook_action('scripts_at_head');?>
	</head>

	<body<?php hook_action('scripts_body_event');?>>
		<header>
			<h1><a href="<?php groupPath();?>"><?php siteName();?></a></h1>
			<p><?php siteSlogan();?></p>
		</header>
		<nav>
			<?php navigation();?>
		</nav>
		<main>
			<?php primary();?>
		</main>
		<aside>
			<?php secondary();?>
		</aside>
		<footer>
			<?php footer('. ');?>
		</footer>
		<?php hook_action('scripts_at_end');?>
	</body>
</html>
<?php hook_action('template_exit');?>
