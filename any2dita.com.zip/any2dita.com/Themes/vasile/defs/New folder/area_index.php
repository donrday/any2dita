<?php
?>
<div class="post">
	<?php if ($postNavtitle != '') echo '<b class="xpdkicker">'.$postNavtitle.'</b><br />'; ?>
	<?php echo endpoint('all');?>
	<?php listMapAsList($config['index']['featuredMap'], 'blurb'); ?>
</div>
<?php
