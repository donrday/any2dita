<?php
// Note for SimpleTheme; the comment markup needs to be adapted to better suit this theme, which lacked a comment example.
// verified wrappers for page layout in winterplain theme.
$postTitleTxt = 'Title text for post';
$postid = '37';
$postURL = '?read=37';
$postDate = date('M d, Y'); //'Jun 13, 2006'; 
$postCategory = 'Mentoring';
$comments[$postid] = array('Very nice.','I don\'t understand you.','May I quote you?','Imitation Gucci bags, cheap');
$numcomments = sizeof($comments);
$tags[$postid] = 'arcu, eget, pretium, porttitor';


?>
	<a href="<?php echo $targurl;?>">
		<!--
		<img width="100%" height="173px" alt="blog feature image"
			onerror="this.src='< ?php echo "$contentDir/$groupName/";?>images/Generic 206 px.png'"
			src="< ?php echo "$contentDir/$groupName/";?>images/< ?php echo $featureImg;?>"/>
			-->
	<h2><?php echo $itemTitle;?></h2>
	</a>
	<div class="date"><?php echo $postDate;?> in <?php echo $postCategory;?></div>
	<div class="body">
		<?php //echo $postShortdesc; ?>
		<?php //echo $postContent; ?>
		<?php echo $itemDesc;?>
	</div>
	<div class="metadata">
		<div class="left">
			<span class="comment"><a href="<?php echo $postURL;?>"><?php echo $numcomments;?> Comments</a></span>
		</div>
		<div class="right">
			<span class="tag"><?php showTags($postid);?></span>
		</div>
		<div class="clearer"></div>
	</div>
<?php

