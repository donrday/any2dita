<?php

// Data for presumed groupName 'any2dita'
// group lookup (as if read from _prefs)
$siteName ='Any2DITA';
$siteSlogan = 'New lamps for old';
$siteOwner = 'Don Day';
$defaultThemeName = 'vasile';

$serviceTypes  = array('about','admin');

$config['admin']['sidebarItems'] = 'themesel,categories2,cats';//,xtypesel,sites';
	$config['admin']['label'] = 'Migrate';
	$config['admin']['url'] = '?tab=admin'; // no leading slash! these must inherit the page context.

$config['about']['sidebarItems'] = 'pages';
	$config['about']['label'] = 'About';
	$config['about']['url'] = '?tab=about';



/* "Group definitions" (these depend on the $groupName as a valid location) */

function groupPath() {
	global $groupName;
	return BASE_URL.$groupName.'/';
}

// Used to house common theme support code (sliders and shortcodes, especially)
function commonPath() {
	global $themesOffset, $themesDir, $themeName;
	return "{$themesOffset}$themesDir/$themeName/";
}

function themePath() {
	global $themesOffset, $themesDir, $themeName;
	return "{$themesOffset}$themesDir/$themeName/";
}

function pagePath($id) {
	global $siteURL;
	$pagepath = SITE_URL.'?page='.$id;
	return $pagepath;
}


?>