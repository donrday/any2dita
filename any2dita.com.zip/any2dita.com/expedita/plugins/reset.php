<?php
//die( 'RESET DONE.<br/>');
?>