<?php
// functions for editor/transform manipulation of save stream

function transformRTF($instr, $prefix="xform") {
	return "IN TRANSFORM RICH TEXT";
}
