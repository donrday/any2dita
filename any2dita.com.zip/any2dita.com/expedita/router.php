<?php

// Router results
$groupName = 'any2DITA';
$serviceType = 'about';
$controller = 'nothing';
$queryType = 'topic';
$resourceName = 'about';

if ($pagenum == '*') {$pagenum = 15;$tabType = 'about';}

?>